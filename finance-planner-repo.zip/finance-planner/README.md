# 🎯 目標理財規劃器

純靜態網頁（HTML + CSS + JavaScript，無任何依賴與建置步驟），以 PV／FV／PMT 為核心，依理財目標反推每月投入並提供調整建議。

## 功能

- 目標預設：退休、買房頭期款、子女教育、自訂
- 計算每月所需 PMT、預估 FV、達成率與資金缺口
- 建議：加碼投入、延長時間、提高報酬率三種調整方式
- 資產成長圖表、報酬率 ±2% 情境分析、通膨換算
- 輸入資料僅存在使用者瀏覽器 localStorage

## 公式（月複利，i = 年報酬率 ÷ 12，n = 年數 × 12）

```
FV  = PV × (1+i)^n + PMT × ((1+i)^n − 1) / i
PMT = (目標FV − PV × (1+i)^n) × i / ((1+i)^n − 1)
```

## 專案結構

```
finance-planner/
├── public/
│   ├── index.html      # 網站本體
│   └── _headers        # Cloudflare 安全標頭
├── .github/workflows/deploy.yml   # 選用：自動部署
├── .gitignore
├── LICENSE
└── README.md
```

## 本機預覽

```bash
cd public && python3 -m http.server 8080
# 開啟 http://localhost:8080
```

## 上傳到 GitHub

```bash
cd finance-planner
git init -b main
git add .
git commit -m "init: finance planner"
git remote add origin https://github.com/<你的帳號>/finance-planner.git
git push -u origin main
```

## 部署到 Cloudflare Pages

### 方式 A：Cloudflare 後台連結 GitHub（最簡單）

1. Cloudflare 後台 → Workers & Pages → Create → Pages → Connect to Git
2. 選擇此 repo
3. Framework preset：None　Build command：留空　Build output directory：`public`
4. Save and Deploy，之後每次 push 自動更新

### 方式 B：GitHub Actions 自動部署

1. 在 Cloudflare 建立 API Token（權限：Account → Cloudflare Pages → Edit）
2. 到 GitHub repo → Settings → Secrets and variables → Actions，新增：
   - `CLOUDFLARE_API_TOKEN`
   - `CLOUDFLARE_ACCOUNT_ID`
3. 先在 Cloudflare 建立名為 `finance-planner` 的 Pages 專案（Direct Upload），或修改 workflow 中的 `--project-name`
4. push 到 `main` 即自動部署

> 本工具僅供試算，不構成投資建議。
